# Batchnet
The Batch Version Of The Internet! Yay!

(Also using powershell)